# -*- coding: utf-8 -*-
"""
Created on Sun Feb 16 20:21:53 2020

@author: Chandra
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import f1_score,classification_report

def heatmap(data):
    fig = plt.figure(figsize = (16,7))
    d = data.groupby(['Year','Month'])['Killed'].sum()
    d = pd.DataFrame(d)
    d = d.fillna(0)
    d.columns = ['count']
    d.reset_index(inplace=True)
    d.columns = ['Year','Month','count']
    d = d.pivot("Month","Year","count")
    d = d.fillna(0)
    sns.heatmap(d).set_title("Number of Deaths")
    plt.show()
    
def succ_fail(data):
    d = pd.DataFrame(data.groupby(['Year','success'])['Year'].count())
    d.columns=['count']
    d.reset_index(inplace=True)
    d["fake"]=0
    color_set = ['#f71325','#20d813']
    fig = plt.figure(figsize = (8,5))
    p = sns.tsplot(time='Year',value='count',condition='success',data=d,unit='fake',color = sns.color_palette(color_set))
    p.set_ylabel("Number of Attacks")
    p.set_xlabel("Year")
    plt.show()
    
def prep(data,threshold):
    l = LabelEncoder()
    class_freq = data[data['gname']!='Unknown']['gname'].value_counts()  # Count frequency of each groups
    data['weaptype1_txt'] = data['weaptype1_txt'].apply(lambda x: 'Vehicle' if x=='Vehicle (not to include vehicle-borne explosives, i.e., car or truck bombs)' else x)
    data = data[data['gname']!='Unknown'] # Remove "Unknown" groups, they contribut more than
    data['provstate'] = data.apply(lambda row: row['city'] if pd.isnull(row['provstate']) else row['provstate'], axis=1)
    data = data.loc[:,data.columns[[1,2,3,5,7,9,11,13,14,16,19,20,21,22,28,34,58,81]]] #Select only intereseted columns
    data = data[(data.crit1==1) & (data.crit2==1) & (data.crit3 ==1) & (data.doubtterr==0)] #Keep rows that are terrorist attacks for sure
    data = data[data['gname'].isin(class_freq.index[:threshold])] #Remove classes having frequency less than class_frequency[threshold]
    data = data.sample(frac=1) #Randomize dataset
    data = data.dropna() 
    data['provstate'] = l.fit_transform(data['provstate']) # Encode all states
    data['gname'] = l.fit_transform(data['gname']) #Encode all groups
    y = data['gname']
    data = data.drop('gname',axis=1)
    train = data[:round(0.85*len(data))] #Split train and test data
    y_train = y[:round(0.85*len(data))]
    test = data[round(0.85*len(data)):]
    y_test = y[round(0.85*len(data)):]
    return train, y_train, test, y_test
    
def predict(model,train,y_train,test,y_test):
    model.fit(train,y_train)
    ypred = model.predict(test)
    return f1_score(y_test,ypred,average='micro')

def piechart_attacks_state(data,Year):
    d = pd.DataFrame(data[data['Year']==Year]['State'].value_counts(sort=True)[:10])
    d.reset_index(inplace=True)
    d.columns=['State','no_of_attacks']
    append = ['Rest of the world',sum(data[data['Year']==Year]['State'].value_counts(sort=True)) - sum(data[data['Year']==Year]['State'].value_counts(sort=True)[:10])]
    d.loc[len(d)]= append
    color_set = ["#e82727","#ff8649","#ffc549","#fced20","#8fe222","#22e28e","#22e2db","#1f85c4","#361599","#d11fce","#00ff99","#fa97fc"]
    fig = plt.figure(figsize = (12,12))
    plt.title(f"Percentage of attacks in each state in {Year}")
    plt.pie(d['no_of_attacks'],labels=d['State'],colors= color_set,autopct='%.1f%%')
    plt.show()
    
def piechart_deaths_state(data,Year):
    d = data[data['Year']==Year]
    d2 = pd.DataFrame(d.groupby('State')['Killed'].sum().sort_values(ascending=False)[:10])
    d2.reset_index(inplace=True)
    append = ['Rest of the united states',(d['Killed'].sum()- d2['Killed'].sum())]
    d2.loc[len(d2)] = append
    color_set = ["#e82727","#ff8649","#ffc549","#fced20","#8fe222","#22e28e","#22e2db","#1f85c4","#361599","#d11fce","#00ff99","#fa97fc"]
    fig = plt.figure(figsize = (12,12))
    plt.title(f"Percentage of deaths in each state {Year}" )
    plt.pie(d2['Killed'],labels=d2['State'],colors= color_set,autopct='%.1f%%')
    plt.show()